Project: Demoblaze E2E Automation

Requirements:
- Node.js installed
- Cypress installed

Installation:
1. Open terminal
2. Run:
   npm install

Execution:
1. Run:
   npx cypress open
2. Select E2E Testing
3. Open spec.cy.js
4. Cypress will automatically execute the test