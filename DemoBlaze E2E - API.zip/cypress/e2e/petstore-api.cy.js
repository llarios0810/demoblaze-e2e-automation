describe('PetStore API Automation', () => {

  const petId = Date.now()

  it('PetStore API full flow', () => {

    // CREATE PET
    cy.request({
      method: 'POST',
      url: 'https://petstore.swagger.io/v2/pet',
      body: {
        id: petId,
        category: {
          id: 1,
          name: 'Dogs'
        },
        name: 'Rocky',
        photoUrls: ['test'],
        tags: [
          {
            id: 1,
            name: 'friendly'
          }
        ],
        status: 'available'
      }
    }).then((response) => {
      expect(response.status).to.eq(200)
      expect(response.body.name).to.eq('Rocky')
    })

    // GET PET BY ID
    cy.request({
      method: 'GET',
      url: `https://petstore.swagger.io/v2/pet/${petId}`
    }).then((response) => {
      expect(response.status).to.eq(200)
      expect(response.body.id).to.eq(petId)
    })

    // UPDATE PET
    cy.request({
      method: 'PUT',
      url: 'https://petstore.swagger.io/v2/pet',
      body: {
        id: petId,
        category: {
          id: 1,
          name: 'Dogs'
        },
        name: 'Max',
        photoUrls: ['test'],
        tags: [
          {
            id: 1,
            name: 'friendly'
          }
        ],
        status: 'sold'
      }
    }).then((response) => {
      expect(response.status).to.eq(200)
      expect(response.body.name).to.eq('Max')
      expect(response.body.status).to.eq('sold')
    })

    // FIND BY STATUS
    cy.request({
      method: 'GET',
      url: 'https://petstore.swagger.io/v2/pet/findByStatus?status=sold'
    }).then((response) => {
      expect(response.status).to.eq(200)

      const foundPet = response.body.find(pet => pet.id === petId)
      expect(foundPet).to.exist
      expect(foundPet.name).to.eq('Max')
    })

  })
})