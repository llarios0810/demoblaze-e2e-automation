describe('Demoblaze E2E Purchase Flow', () => {

  it('Should complete purchase successfully', () => {

    cy.visit('https://www.demoblaze.com/')

    cy.on('window:alert', () => true)

    // Primer producto
    cy.contains('Samsung galaxy s6').click()
    cy.contains('Add to cart').click()
    cy.wait(2000)

    cy.contains('Home').click()

    // Segundo producto
    cy.contains('Nokia lumia 1520').click()
    cy.contains('Add to cart').click()
    cy.wait(2000)

    // Carrito
    cy.contains('Cart').click()

    // Validaciones
    cy.contains('Samsung galaxy s6').should('exist')
    cy.contains('Nokia lumia 1520').should('exist')

    // Comprar
    cy.contains('Place Order').click()

    cy.get('#name').type('Luis')
    cy.get('#country').type('Honduras')
    cy.get('#city').type('Tegucigalpa')
    cy.get('#card').type('123456789')
    cy.get('#month').type('05')
    cy.get('#year').type('2026')

    cy.contains('Purchase').click()

    cy.contains('Thank you for your purchase!').should('be.visible')

  })

})